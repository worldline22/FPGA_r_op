#pragma once

#include <map>
#include <string>
#include <iostream>
#include "object.h"

bool readAndCreateLib(std::string libFilename);